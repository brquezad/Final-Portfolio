
airData<- fromJSON("airsurvey.json") %>% as.data.frame

names(airData) <- gsub("\\.", "", names(airData))
airData$Departuredelayin<-  na.omit(airData$Age)


#-------------------------------------------

ggplot(airData,aes(x=FlightDistance))+geom_histogram(bins= 15)+ggtitle("Flight Distance Count")
#Most flight distances are skewed left 

ggplot(airData, aes(x=FlightDistance, y =Likelihoodtorecommend))+geom_point()
# There seems to be no correlation between flight distance and likelihood to recommend 
#----------------------------------------
countType<-sqldf("select TypeofTravel, COUNT(TypeofTravel) as NumberOfTravelers from airData group by TypeofTravel ")
ggplot(countType, aes(x=TypeofTravel, y =NumberOfTravelers))+geom_bar(stat='identity')+ggtitle("Number of Travelers for Types of Travel")
# There's also a larger number of people who travel for business (3041), compared to Mileage Tickets (389) and Personal Travel(1570)


LikelihoodbyType<-sqldf("select TypeofTravel, AVG(Likelihoodtorecommend) as AverageLikelihood from airData group by TypeofTravel")
ggplot(LikelihoodbyType, aes(x=TypeofTravel,y=AverageLikelihood)) + 
  geom_bar(stat='identity')+ggtitle("Average Likelihood to Recommend by Type of travel")

# Business Travel also has a higher average Likelihood, with an average of 8.28. 

#------------------------------------
countGender<-sqldf("select Gender, COUNT(Gender) as Count from airData group by Gender")
ggplot(countGender, aes(x=Gender, y=Count))+geom_bar(stat = 'identity')+ggtitle("Gender Count")
# There's a higher female (2820) compared to male(2120)

LikelihoodbyGender<-sqldf("select Gender, AVG(likelihoodtorecommend) as AverageLikelihood from airData group by Gender")
ggplot(LikelihoodbyGender, aes(x=Gender, y = AverageLikelihood))+geom_bar(stat='identity')+ggtitle("Average Likelihood by Gender")

#Although female have a higher head count, male have a higher average Likelihood.
#------------------------------------------
ggplot(airData, aes(x=FlightsPerYear))+geom_histogram(bins=15)+ggtitle("Flights per Year Count")

#Flights per year is skewed left

ggplot(airData, aes(x=FlightsPerYear, y = Likelihoodtorecommend))+geom_point()

#There wasnt much correlation for the amount of flights taken per year and the Likelihood

#----------------------------------------------------
ggplot(airData, aes(x=Age))+geom_histogram(bins=20)+ggtitle("Age Count")

#Age seems to be a normal distribution, with several different ages 
ggplot(airData, aes(x=Age, y =Likelihoodtorecommend))+geom_point()

#Age also seems to not have an impact on Likelihood , as there seems to be no correlation 

#-------------------------------------------------------------
countClass<-sqldf('select Class, COUNT(Class) as Count from airData group by Class')
ggplot(countClass, aes(x=Class, y=Count))+geom_bar(stat='identity')+ggtitle("Class Count")
#There's a signficant amount of travelers flying in the economic class (4084) compared to eco plus (497) and business(419)

LikelihoodbyClass<-sqldf('select Class, AVG(Likelihoodtorecommend) as AverageLikelihood from airData group by Class')
ggplot(LikelihoodbyClass, aes(x=Class, y=AverageLikelihood))+geom_bar(stat='identity')+ggtitle("Average Likelihood by Class")
#-------------------------------------------------------------------

ggplot(airData, aes(x = TotalFreqFlyerAccts))+geom_histogram(bins=5)+ggtitle("Total Freq Flyer Accounts Count")
#The majority of members aremore likely to have less than two frequent flyer accounts, as the total freq flyer account is skewed left
ggplot(airData, aes(x=TotalFreqFlyerAccts, y=Likelihoodtorecommend))+geom_point()

#There's a slight positive correlation, with more freq flyer accounts are less likely to give a lower Likelihood 

#--------------------------------------------------------------------
countStatus<-sqldf('select AirlineStatus, COUNT(AirlineStatus) as Count from airData group by AirlineStatus')
ggplot(countStatus, aes(x=AirlineStatus, y = Count))+geom_bar(stat='identity')+ggtitle("Airline Status Count")
#The majority of members have a blue status (3442) compared to silver(987), gold(421), and platinum(150)

LikelihoodbyStatus<-sqldf('select AirlineStatus, AVG(Likelihoodtorecommend) as AverageLikelihood from airData group by AirlineStatus')
ggplot(LikelihoodbyStatus, aes(x=AirlineStatus, y =AverageLikelihood))+geom_bar(stat='identity')+ggtitle("Average Likelihood by Status")
#Silver status has the highest average Likelihood with an average of 8.641337, compared to blue (7.023242), gold(7.971496), and platinum (7.200000)
#------------------------------------------------------

ggplot(airData, aes(x=Loyalty))+geom_histogram(bins=15)+ggtitle("Loyalty Count")

#loyalty is skewed to the left, signifying there's not much moyalty towards the airline

ggplot(airData, aes(x=Loyalty, y=Likelihoodtorecommend))+geom_point()
#Seems to be no correlation betwen loyalty and likelihood to recommend

#----------------------------------------------------

ggplot(airData, aes(x=PriceSensitivity))+geom_histogram(bins=5)+ggtitle("Price Sensitivity Count")

# Price sensitivity is slightly skewed to the left

ggplot(airData, aes(x=PriceSensitivity, y =Likelihoodtorecommend))+geom_point()

#There seems to be no correlation between price sensitivity and likelihood to recommend 

#---------------------------------------------------------
LikelihoodbyPartner<-sqldf("select PartnerName, AVG(Likelihoodtorecommend) as AverageLikelihood from airData group by PartnerName")

ggplot(LikelihoodbyPartner, aes(x=PartnerName, y =AverageLikelihood))+geom_bar(stat='identity')+ggtitle("Average Likelihood to Recommend by Partner Name")

#----------------------------------------------------

#6. 
us<-map_data('state')
airData$OriginStateLower<-tolower(airData$OriginState)


air_map<- ggplot(airData, aes(map_id = OriginStateLower))+
  geom_map(map=us,aes(fill= Likelihoodtorecommend))+
  expand_limits(x=us$lon,y=us$lat) +
  geom_point(data = airData, aes(x=airData$olong, y = airData$olat, color=Likelihoodtorecommend))+
  ggtitle('Likelihood to Recommend by State')+
  coord_map()

air_map
#This map is displaying the average likelihood to recommend by state, as well as points for the oirgin of the flights in the data

#---------------------------------

#7. 
promoterData<-sqldf('select * from airData where Likelihoodtorecommend>8')

promoterCountType<-sqldf("select TypeofTravel, COUNT(TypeofTravel) as NumberOfTravelers from promoterData group by TypeofTravel ")
ggplot(promoterCountType, aes(x=TypeofTravel, y =NumberOfTravelers))+geom_bar(stat='identity') +ggtitle("Number of Travelers for Promoters")

#------------------------------------
promoterCountGender<-sqldf("select Gender, COUNT(Gender) as Count from promoterData group by Gender")
ggplot(promoterCountGender, aes(x=Gender, y=Count))+geom_bar(stat = 'identity') +ggtitle("Gender Count for Promoters")

#----------------------------------------------------

promoter_map<- ggplot(promoterData, aes(map_id = OriginStateLower))+
  geom_map(map=us,aes(fill= Likelihoodtorecommend))+
  expand_limits(x=us$lon,y=us$lat) +
  geom_point(data = promoterData, aes(x=promoterData$olong, y = promoterData$olat, color=Likelihoodtorecommend))+
  ggtitle('Likelihood to Recommend by State - Promoters')+
  coord_map()

promoter_map


#---
detractorData<-sqldf('select*from airData where Likelihoodtorecommend<7')


detractorCountType<-sqldf("select TypeofTravel, COUNT(TypeofTravel) as NumberOfTravelers from detractorData group by TypeofTravel ")
ggplot(detractorCountType, aes(x=TypeofTravel, y =NumberOfTravelers))+geom_bar(stat='identity') +ggtitle("Number of Travelers for Detractors")


#------------------------------------
detractorCountGender<-sqldf("select Gender, COUNT(Gender) as Count from detractorData group by Gender")
ggplot(detractorCountGender, aes(x=Gender, y=Count))+geom_bar(stat = 'identity') +ggtitle("Gender Count for Detractors")

#---------------------------------------------------------
detractor_map<- ggplot(detractorData, aes(map_id = OriginStateLower))+
  geom_map(map=us,aes(fill= Likelihoodtorecommend))+
  expand_limits(x=us$lon,y=us$lat) +
  geom_point(data = detractorData, aes(x=detractorData$olong, y = detractorData$olat, color=Likelihoodtorecommend))+
  ggtitle('Likelihood to Recommend by State - Detractors')+
  coord_map()

detractor_map

#---------------------------------

#8
airData$detractor<-airData$Likelihoodtorecommend<7


airData$detractor<-as.factor(airData$detractor)
airData$Age<-as.factor(airData$Age)
airData$Gender<-as.factor(airData$Gender)
airData$PartnerName<-as.factor(airData$PartnerName)
airDataX<-as(airData, 'transactions')


ruleset<-apriori(airData, parameter = list(support =.14, confidence=.98),appearance = list(default = 'lhs', rhs='detractor=TRUE'))
detach(package:tm, unload=TRUE)
inspect(ruleset)
# Based on this data, some attributes that are connected with someone who doesn't feel satisfied with the airline include:
# one who's taking a personal travel, and traveling economically, with a price sensitivity between 1-4 and a likelihood to recommend 
# between 2-6

#---------------------------------------
#9. 

ageLM<- lm(formula =Likelihoodtorecommend~Age, data=airData)
plot(airData$Age,airData$Likelihoodtorecommend)
summary(ageLM)
abline(ageLM)

genderLM<- lm(formula =Likelihoodtorecommend~Gender, data=airData)
plot(airData$Gender,airData$Likelihoodtorecommend)
summary(genderLM)
abline(genderLM)

TypeofTravelLM<- lm(formula =Likelihoodtorecommend~TypeofTravel, data=airData)
summary(TypeofTravelLM)

FlightDistanceLM<- lm(formula =Likelihoodtorecommend~FlightDistance, data=airData)
plot(airData$FlightDistance,airData$Likelihoodtorecommend)
abline(FlightDistanceLM)
summary(FlightDistanceLM)

DepartureDelayinMinutesLM<- lm(formula =Likelihoodtorecommend~DepartureDelayinMinutes, data=airData)
plot(airData$DepartureDelayinMinutes,airData$Likelihoodtorecommend)
abline(DepartureDelayinMinutesLM)
summary(DepartureDelayinMinutesLM)

#The best predictors are: Type of Travel(Adjusted R-squared value of 0.3301, p-value<2.2e-16) and Age(Adjusted R-Squared value of 0.1628, p-value<2.2e-16)
#other attributes: Gender(R-squared: 0.01596, p-value:2.2e-16), Flight Dsitance(R-Squared:-.001523, p-value:0.6253), Departure Delay in Minutes(R-Squared: 0.005374, p-value:1.616e-07)

#--------------------------------------------

#10


randIndex<-sample(1:dim(airData)[1])
cutPoint2_3<-floor(2*dim(airData)[1]/3)
trainData<-airData[randIndex[1:cutPoint2_3],]
testData<-airData[randIndex[(cutPoint2_3+1):dim(airData)[1]],]

ageSVM<-ksvm(detractor~Age, data=trainData, kernel='rbfdot', kpar="automatic",C=5,cross=3,prob.model=TRUE)
ageSVM
#cross-validation error: 0.19862, training error: 0.191119

agePred<-predict(ageSVM, testData, type='votes')
ageTable<-data.frame(testData$detractor,agePred[1,])
ageMatrix<- table(ageTable)
ageMatrix

error_cases<-sum(ageMatrix[1,1],ageMatrix[2,2])
total_cases<-sum(ageMatrix)
error_cases/total_cases
#21.65567% error rate


genderSVM<-ksvm(detractor~Gender, data=trainData, kernel='rbfdot', kpar="automatic",C=5,cross=3,prob.model=TRUE)
genderSVM
# cross validation error: .20132, training error: .20132

genderPred<-predict(genderSVM, testData, type = 'votes')
genderTable<-data.frame(testData$detractor,genderPred[1,])
genderMatrix<- table(genderTable)
genderMatrix

error_cases<-sum(genderMatrix[2,1])
total_cases<-sum(genderMatrix)
error_cases/total_cases
#0.2183563 error rate


typeoftravelSVM<-ksvm(detractor~TypeofTravel, data=trainData, kernel='rbfdot', kpar="automatic",C=5,cross=3,prob.model=TRUE)
typeoftravelSVM
# cross validation error: 0.19742, training error:0.19742

typeoftravelPred<-predict(typeoftravelSVM, testData, type ='votes')
typeoftravelTable<-data.frame(testData$detractor,typeoftravelPred[1,])
typeoftravelMatrix<- table(typeoftravelTable)
typeoftravelMatrix

error_cases<-sum(genderMatrix[2,1])
total_cases<-sum(genderMatrix)
error_cases/total_cases
#21.83563% error rate

flightdistanceSVM<-ksvm(detractor~FlightDistance, data=trainData, kernel='rbfdot', kpar="automatic",C=5,cross=3,prob.model=TRUE)
flightdistanceSVM
#cross validation error: 0.20132, training error:0.20132

flightdistancePred<-predict(flightdistanceSVM, testData, type ='votes')
flightdistanceTable<-data.frame(testData$detractor,flightdistancePred[1,])
flightdistanceMatrix<- table(flightdistanceTable)
flightdistanceMatrix

error_cases<-sum(flightdistanceMatrix[2,1])
total_cases<-sum(flightdistanceMatrix)
error_cases/total_cases
#21.835634 error rate