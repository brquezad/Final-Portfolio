
detractorCountType<-sqldf("select TypeofTravel, COUNT(TypeofTravel) as NumberOfTravelers from detractorData group by TypeofTravel ")
ggplot(detractorCountType, aes(x=TypeofTravel, y =NumberOfTravelers))+geom_bar(stat='identity') +ggtitle("Number of Travelers for Detractors")


#------------------------------------
detractorCountGender<-sqldf("select Gender, COUNT(Gender) as Count from detractorData group by Gender")
ggplot(detractorCountGender, aes(x=Gender, y=Count))+geom_bar(stat = 'identity') +ggtitle("Gender Count for Detractors")

#---------------------------------------------------------
detractor_map<- ggplot(detractorData, aes(map_id = OriginStateLower))+
  geom_map(map=us,aes(fill= Likelihoodtorecommend))+
  expand_limits(x=us$lon,y=us$lat) +
  geom_point(data = detractorData, aes(x=detractorData$olong, y = detractorData$olat, color=Likelihoodtorecommend))+
  ggtitle('Likelihood to Recommend by State - Detractors')+
  coord_map()

detractor_map